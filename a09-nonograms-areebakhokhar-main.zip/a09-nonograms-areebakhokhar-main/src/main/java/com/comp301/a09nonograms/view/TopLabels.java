package com.comp301.a09nonograms.view;

import com.comp301.a09nonograms.controller.Controller;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class TopLabels implements FXComponent {
  private final Controller controller;

  public TopLabels(Controller controller) {
    this.controller = controller;
  }

  @Override
  public Parent render() {
    HBox toplabels = new HBox();
    // ArrayList<VBox> topclues = new ArrayList<>();
    // VBox extra = new VBox();
    // topclues.add(extra);
    int[] a1;
    for (int v = 0; v < this.controller.getClues().getWidth(); v++) {
      a1 = this.controller.getClues().getColClues(v);
      VBox temp = new VBox();
      // make vboxes with number of clues
      for (int x = 0; x < this.controller.getClues().getColCluesLength(); x++) {
        Button l = new Button(String.valueOf(this.controller.getClues().getColClues(v)[x]));
        l.setPrefSize(60, 60);
        if (this.controller.getClues().getColClues(v)[x] == 0) {
          l = new Button("");
        }
        l.setPrefSize(60, 60);
        temp.getChildren().add(l);
      }
      toplabels.getChildren().add(temp);
    }
    /*
       for (int a = 0; a < this.controller.getClues().getWidth(); a++) {
         toplabels.getChildren().add(topclues.get(a));

       }

    */

    return toplabels;
  }
}
