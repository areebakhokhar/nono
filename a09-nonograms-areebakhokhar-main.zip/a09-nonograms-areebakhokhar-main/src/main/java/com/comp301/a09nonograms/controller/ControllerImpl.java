package com.comp301.a09nonograms.controller;

import com.comp301.a09nonograms.model.Clues;
import com.comp301.a09nonograms.model.Model;
import com.comp301.a09nonograms.model.ModelImpl;

import java.util.Random;

public class ControllerImpl implements Controller {
  private final Model model;

  public ControllerImpl(Model model) {
    if (model == null) {
      throw new IllegalArgumentException();
    }
    this.model = model;
  }

  @Override
  public Clues getClues() {
    ModelImpl model = (ModelImpl) this.model;
    return (model).getClues();
  }

  @Override
  public boolean isSolved() {
    return this.model.isSolved();
  }

  @Override
  public boolean isShaded(int row, int col) {
    return this.model.isShaded(row, col);
  }

  @Override
  public boolean isEliminated(int row, int col) {
    return this.model.isEliminated(row, col);
  }

  @Override
  public void toggleShaded(int row, int col) {
    this.model.toggleCellShaded(row, col);
  }

  @Override
  public void toggleEliminated(int row, int col) {
    this.model.toggleCellEliminated(row, col);
  }

  @Override
  public void nextPuzzle() {
    // if(this.model.getPuzzleIndex() >= this.getPuzzleCount()){
    //    this.model.setPuzzleIndex(0);
    // }
    // this.model.setPuzzleIndex(this.model.getPuzzleIndex() + 1);
    this.model.setPuzzleIndex((this.getPuzzleIndex() + 1) % this.getPuzzleCount());
  }

  @Override
  public void prevPuzzle() {
    if (this.model.getPuzzleIndex() == 0) {
      this.model.setPuzzleIndex(this.getPuzzleCount());
    }
    this.model.setPuzzleIndex(this.model.getPuzzleIndex() - 1);
  }

  @Override
  public void randPuzzle() {
    Random random = new Random();
    // generate random number from 0 to puzzle count
    int randomnum = random.nextInt(this.getPuzzleCount() - 1);
    while (randomnum == this.getPuzzleIndex()) {
      randomnum = random.nextInt(this.getPuzzleCount() - 1);
    }
    this.model.setPuzzleIndex(randomnum);
  }

  @Override
  public void clearBoard() {
    this.model.clear();
  }

  @Override
  public int getPuzzleIndex() {
    return this.model.getPuzzleIndex();
  }

  @Override
  public int getPuzzleCount() {
    return this.model.getPuzzleCount();
  }

  public String getCellState(int row, int col) {
    String cellstate = "";
    if (this.isEliminated(row, col)) {
      cellstate = "eliminated";
    } else if (this.isShaded(row, col)) {
      cellstate = "shaded";
    } else {
      cellstate = "blank";
    }
    return cellstate;
  }
}
