package com.comp301.a09nonograms.view;

import com.comp301.a09nonograms.controller.Controller;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class View implements FXComponent {
  private final Controller controller;
  private final FXComponent PuzzleView;
  private final FXComponent ControlView;
  private final FXComponent TopLabels;
  private final FXComponent LeftLabels;
  private final FXComponent LabelView;
  private final FXComponent MessageView;

  public View(Controller controller) {
    this.controller = controller;
    this.PuzzleView = new PuzzleView(controller);
    this.ControlView = new ControlView(controller);
    this.TopLabels = new TopLabels(controller);
    this.LeftLabels = new LeftLabels(controller);
    this.LabelView = new LabelView(controller);
    this.MessageView = new MessageView(controller);
  }

  @Override
  public Parent render() {
    VBox main = new VBox();
    HBox sub = new HBox();
    HBox sub2 = new HBox();
    HBox sub3 = new HBox();
    HBox sub4 = new HBox();
    HBox sub5 = new HBox();

    sub5.getChildren().add(this.LabelView.render());
    sub4.getChildren().add(this.ControlView.render());
    sub.getChildren().add(this.TopLabels.render());
    sub2.getChildren().add(this.LeftLabels.render());
    sub2.getChildren().add(this.PuzzleView.render());
    sub3.getChildren().add(MessageView.render());
    sub.setAlignment(Pos.TOP_RIGHT);
    main.getChildren().add(sub5);
    main.getChildren().add(sub4);
    main.getChildren().add(sub);
    main.getChildren().add(sub2);
    main.getChildren().add(sub3);

    /*
    main.getChildren().add(this.LabelView.render());
    main.getChildren().add(this.ControlView.render());
    main.getChildren().add(this.TopLabels.render());
    sub.getChildren().add(this.LeftLabels.render());
    sub.getChildren().add(this.PuzzleView.render());
    main.getChildren().add(sub);
    main.getChildren().add(this.MessageView.render());
    // main.getChildren().add(this.LeftLabels.render());
    // main.getChildren().add(this.PuzzleView.render());

     */
    return main;
  }
}
