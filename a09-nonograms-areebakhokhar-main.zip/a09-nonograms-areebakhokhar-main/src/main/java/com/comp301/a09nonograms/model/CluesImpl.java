package com.comp301.a09nonograms.model;

public final class CluesImpl implements Clues {
  private final int height;
  private final int width;
  private final int[][] rowClues;
  private final int[][] colClues;

  public CluesImpl(int[][] rowClues, int[][] colClues) {
    this.height = rowClues.length;
    this.width = colClues.length;
    this.rowClues = rowClues;
    this.colClues = colClues;
  }

  @Override
  public int getWidth() {
    return this.width;
  }

  @Override
  public int getHeight() {
    return this.height;
  }

  @Override
  public int[] getRowClues(int index) {
    return this.rowClues[index];
  }

  @Override
  public int[] getColClues(int index) {
    return this.colClues[index];
  }

  @Override
  public int getRowCluesLength() {
    int max;
    max = this.rowClues[0].length;
    for (int i = 0; i < this.rowClues.length; i++) {
      if (this.rowClues[i].length > max) {
        max = this.rowClues[i].length;
      }
    }
    return max;
  }

  @Override
  public int getColCluesLength() {
    int max;
    max = this.colClues[0].length;
    for (int i = 0; i < this.colClues.length; i++) {
      if (this.colClues[i].length > max) {
        max = this.colClues[i].length;
      }
    }
    return max;
  }
}
