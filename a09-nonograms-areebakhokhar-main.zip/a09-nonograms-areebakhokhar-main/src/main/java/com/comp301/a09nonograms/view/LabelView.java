package com.comp301.a09nonograms.view;

import com.comp301.a09nonograms.controller.Controller;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class LabelView implements FXComponent {
  Controller controller;

  public LabelView(Controller controller) {
    this.controller = controller;
  }

  @Override
  public Parent render() {
    HBox sub = new HBox();
    String index = String.valueOf(this.controller.getPuzzleIndex() + 1);
    String total = String.valueOf(this.controller.getPuzzleCount());
    Label l = new Label("Puzzle " + index + " of " + total);
    sub.getChildren().add(l);
    return sub;
  }
}
