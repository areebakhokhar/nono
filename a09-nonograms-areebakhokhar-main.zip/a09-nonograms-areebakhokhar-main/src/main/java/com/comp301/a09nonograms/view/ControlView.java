package com.comp301.a09nonograms.view;

import com.comp301.a09nonograms.controller.Controller;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;

public class ControlView implements FXComponent {
  private final Controller controller;

  public ControlView(Controller controller) {
    this.controller = controller;
  }

  @Override
  public Parent render() {
    HBox controlpane = new HBox();
    // prev button
    Button prevbutton = new Button("Previous");
    prevbutton.setOnAction(
        (ActionEvent event) -> {
          this.controller.prevPuzzle();
        });
    controlpane.getChildren().add(prevbutton);

    // next button
    Button nextbutton = new Button("Next");
    nextbutton.setOnAction(
        (ActionEvent event) -> {
          this.controller.nextPuzzle();
        });
    controlpane.getChildren().add(nextbutton);

    // random button
    Button randbutton = new Button("Random");
    randbutton.setOnAction(
        (ActionEvent event) -> {
          this.controller.randPuzzle();
        });
    controlpane.getChildren().add(randbutton);

    // clear button
    Button clearbutton = new Button("Clear");
    clearbutton.setOnAction(
        (ActionEvent event) -> {
          this.controller.clearBoard();
        });
    controlpane.getChildren().add(clearbutton);

    return controlpane;
  }
}
