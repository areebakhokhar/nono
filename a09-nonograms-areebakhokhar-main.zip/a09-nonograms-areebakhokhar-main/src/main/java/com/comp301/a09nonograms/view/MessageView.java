package com.comp301.a09nonograms.view;

import com.comp301.a09nonograms.controller.Controller;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class MessageView implements FXComponent {
  Controller controller;

  public MessageView(Controller controller) {
    this.controller = controller;
  }

  @Override
  public Parent render() {

    HBox message = new HBox();
    if (this.controller.isSolved()) {
      Label l = new Label("Puzzle is solved");
      message.getChildren().add(l);
    } else {
      Label h = new Label("Puzzle is not solved");
      message.getChildren().add(h);
    }

    return message;
  }
}
