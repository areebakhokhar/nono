package com.comp301.a09nonograms.model;

import java.util.ArrayList;
import java.util.List;

public class ModelImpl implements Model {
  private final List<Clues> clues;
  private final List<Puzzle> puzzles;
  private final List<ModelObserver> observers;
  private int curindex;

  public ModelImpl(List<Clues> clues) {
    this.clues = clues;
    this.curindex = 0;
    this.puzzles = new ArrayList<>(clues.size());
    this.observers = new ArrayList<>(1000);

    for (Clues c : this.clues) {
      Puzzle p = new Puzzle(c);
      this.puzzles.add(p);
    }
  }

  @Override
  public int getPuzzleCount() {
    return this.puzzles.size();
  }

  @Override
  public int getPuzzleIndex() {
    return this.curindex;
  }

  @Override
  public void setPuzzleIndex(int index) {
    if (index < 0) {
      throw new IllegalArgumentException();
    }
    this.curindex = index;
    notify(this);
  }

  @Override
  public void addObserver(ModelObserver observer) {
    observers.add(observer);
  }

  @Override
  public void removeObserver(ModelObserver observer) {
    observers.remove(observer);
  }

  @Override
  public boolean isSolved() {
    return this.puzzles.get(getPuzzleIndex()).ColumnCheck()
        && this.puzzles.get(getPuzzleIndex()).RowCheck();
  }

  @Override
  public boolean isShaded(int row, int col) {
    if (row < 0 || col < 0) {
      throw new IllegalArgumentException();
    }
    return this.puzzles.get(this.curindex).getBoard().isShaded(row, col);
  }

  @Override
  public boolean isEliminated(int row, int col) {
    if (row < 0 || col < 0) {
      throw new IllegalArgumentException();
    }
    return this.puzzles.get(this.curindex).getBoard().isEliminated(row, col);
  }

  @Override
  public boolean isSpace(int row, int col) {
    if (row < 0 || col < 0) {
      throw new IllegalArgumentException();
    }
    return this.puzzles.get(this.curindex).getBoard().isSpace(row, col);
  }

  @Override
  public void toggleCellShaded(int row, int col) {
    if (row < 0 || col < 0) {
      throw new IllegalArgumentException();
    }
    this.puzzles.get(this.curindex).getBoard().toggleCellShaded(row, col);
    notify(this);
  }

  @Override
  public void toggleCellEliminated(int row, int col) {
    if (row < 0 || col < 0) {
      throw new IllegalArgumentException();
    }
    this.puzzles.get(this.curindex).getBoard().toggleCellEliminated(row, col);
    notify(this);
  }

  @Override
  public void clear() {
    this.puzzles.get(this.curindex).getBoard().clear();
    notify(this);
  }

  @Override
  public int getWidth() {
    return this.puzzles.get(this.curindex).getClue().getWidth();
  }

  @Override
  public int getHeight() {
    return this.puzzles.get(this.curindex).getClue().getHeight();
  }

  @Override
  public int[] getRowClues(int index) {
    if (index < 0) {
      throw new IllegalArgumentException();
    }
    return this.puzzles.get(this.curindex).getClue().getRowClues(index);
  }

  @Override
  public int[] getColClues(int index) {
    if (index < 0) {
      throw new IllegalArgumentException();
    }
    return this.puzzles.get(this.curindex).getClue().getColClues(index);
  }

  @Override
  public int getRowCluesLength() {
    return this.puzzles.get(this.curindex).getClue().getRowCluesLength();
  }

  @Override
  public int getColCluesLength() {
    return this.puzzles.get(this.curindex).getClue().getColCluesLength();
  }

  public Clues getClues() {
    return this.puzzles.get(curindex).getClue();
  }

  private void notify(Model m) {
    for (ModelObserver o : observers) {
      o.update(m);
    }
  }
}
