package com.comp301.a09nonograms;

import com.comp301.a09nonograms.view.AppLauncher;
import javafx.application.Application;

public class Main {
  public static void main(String[] args) {
    Application.launch(AppLauncher.class);
  }
}
