package com.comp301.a09nonograms.model;

public class Puzzle {
  private final Clues clues;
  private final Board board;

  public Puzzle(Clues clues) {
    this.clues = clues;
    this.board = new BoardImpl(clues.getHeight(), clues.getWidth());
  }

  public Clues getClue() {
    return this.clues;
  }

  public Board getBoard() {
    return this.board;
  }

  /*
   // start checking rows then columns
    boolean solved = false;
    for (int row = 0; row < this.getHeight(); row++) {
      solved = false;
      int total = 0;
      int shaded = 0;
      for (int i = 0; i < this.getRowCluesLength(); i++) {
        total += this.getRowClues(row)[i];
        if (this.getRowClues(row)[i] != 0) {
          solved = false;
        }
        // if (this.getRowClues(row)[i] == 0) {
        // ??
        // }
      }
      for (int column = 0; column < this.getWidth(); column++) {
        if (this.isShaded(row, column)) {
          shaded++;
        }
      }

      if (shaded == total) {
        solved = true;
      }
    }
    return solved;
  }


   */

  // First check rows then check columns then and them in isSolved and add a bunch of edge cases

  public boolean RowCheck() {
    boolean RowisSolved = false;
    for (int row = 0; row < this.clues.getHeight(); row++) {
      int rowsum = 0;
      int zerosum = 0;
      // int eliminated = 0;
      // int blank = 0;
      // int[] cluearray = this.clues.getRowClues(row);
      // int counter;

      // boolean whenisEliminated = false;
      // boolean whenisShaded = false;
      boolean rowisZero = false;
      boolean firstShade = false;

      for (int j = 0; j < this.clues.getRowCluesLength(); j++) {
        rowsum += this.clues.getRowClues(row)[j];
        if (this.clues.getRowClues(row)[j] == 0) {
          zerosum++;
        }
      }

      if (((this.clues.getRowCluesLength() == zerosum))
          || zerosum == (this.clues.getRowCluesLength() - 1)) {
        rowisZero = true;
      }

      // if(eliminated == 0){
      //  return false;
      // }

      int shaded = 0;
      int count = 0;
      int index = zerosum;
      for (int col = 0; col < this.clues.getWidth(); col++) {

        // base case
        if (rowisZero && this.clues.getRowCluesLength() == zerosum) {
          col = this.clues.getWidth();

          // if (this.getRowClues(row)[i] == 0) {
          // ??
          // }

          // int shaded = 0;

          // edge cases
        } else if (this.getBoard().isShaded(row, col)
            && (rowisZero == false)
            && (firstShade == false)) {
          count = count + 1;
          firstShade = true;
          shaded = shaded + 1;
          // whenisshaded = true;
          // wheniseliminated = false;
        } else if (this.getBoard().isShaded(row, col) && rowisZero) {
          firstShade = true;
          shaded = shaded + 1;
          // whenisshaded = true;
          // wheniseliminated = false;

        } else if (count == this.clues.getRowClues(row)[index]
            && (this.getBoard().isShaded(row, col)) == false) {
          count = 0;
          firstShade = false;
          index = index + 1;
          // whenisshaded = true;
          // wheniseliminated = false;
        }
      }
      if (shaded == rowsum) {
        RowisSolved = true;
      } else {
        return false;
      }
    }
    return RowisSolved;
  }

  public boolean ColumnCheck() {
    boolean ColisSolved = false;

    for (int col = 0; col < this.clues.getWidth(); col++) {
      int colsum = 0;
      boolean colisZero = false;
      boolean firstShade = false;
      // boolean whenisEliminated = false;
      // boolean whenisShaded = false;
      // int eliminated = 0;
      // int blank = 0;
      // int[] cluearray = this.clues.getRowClues(col);
      // int counter;

      int zerosum = 0;

      for (int j = 0; j < this.clues.getColCluesLength(); j++) {
        colsum += this.clues.getColClues(col)[j];
        if (this.clues.getColClues(col)[j] == 0) {
          zerosum++;
        }
      }
      if (zerosum == (this.clues.getColCluesLength() - 1)
          || ((this.clues.getColCluesLength() == zerosum))) {
        colisZero = true;
      }

      int shaded = 0;
      int count = 0;
      int index = zerosum;
      for (int row = 0; row < this.clues.getHeight(); row++) {
        // all of the base and edge cases
        if (colisZero && this.clues.getColCluesLength() == zerosum) {
          row = this.clues.getHeight();
        } else if (this.getBoard().isShaded(row, col) && colisZero) {
          firstShade = true;
          shaded = shaded + 1;
          // whenisshaded = true;
          // wheniseliminated = false;
        } else if (this.getBoard().isShaded(row, col)
            && (colisZero == false)
            && (firstShade == false)) {
          count = count + 1;
          firstShade = true;
          shaded = shaded + 1;
          // whenisshaded = true;
        } else if (count == this.clues.getColClues(col)[index]
            && (this.getBoard().isShaded(row, col) == false)
            && (colisZero == false)) {
          firstShade = false;
          count = 0;
          index = index + 1;
          // whenisshaded = false;
          // wheniseliminated = false;
        }
      }

      // final check
      if (shaded == colsum) {
        ColisSolved = true;
      } else {
        ColisSolved = false;
        return false;
      }
    }
    return ColisSolved;
  }
}
