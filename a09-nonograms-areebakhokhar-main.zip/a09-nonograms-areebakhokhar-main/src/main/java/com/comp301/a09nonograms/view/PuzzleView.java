package com.comp301.a09nonograms.view;

import com.comp301.a09nonograms.controller.Controller;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.GridPane;

public class PuzzleView implements FXComponent {
  private final Controller controller;

  public PuzzleView(Controller controller) {
    this.controller = controller;
  }

  @Override
  public Parent render() {
    FXComponent toplabels = new TopLabels(this.controller);
    // if left click --> toggleshaded
    // if right click --> toggleeliminated

    GridPane grid = new GridPane();

    for (int i = 0;
        i < this.controller.getClues().getHeight();
        i++) { // check if get height or get width
      for (int j = 0; j < this.controller.getClues().getWidth(); j++) {
        Button b1 = new Button();
        b1.setPrefSize(60, 60);

        if (this.controller.isEliminated(i, j)) {
          b1.setStyle("-fx-background-color: Red");
        } else if (this.controller.isShaded(i, j)) {
          b1.setStyle("-fx-background-color: Black");
        } else {
          b1.setStyle("-fx-background-color: lightgrey");
        }

        b1.setOnMouseClicked(
            event -> {
              if (event.getButton() == MouseButton.PRIMARY) {
                this.controller.toggleShaded(GridPane.getRowIndex(b1), GridPane.getColumnIndex(b1));
              } else if (event.getButton() == MouseButton.SECONDARY) {
                this.controller.toggleEliminated(
                    GridPane.getRowIndex(b1), GridPane.getColumnIndex(b1));
              }
            });

        grid.add(b1, j, i);
      }
    }
    grid.setGridLinesVisible(true);
    return grid;
  }
}
