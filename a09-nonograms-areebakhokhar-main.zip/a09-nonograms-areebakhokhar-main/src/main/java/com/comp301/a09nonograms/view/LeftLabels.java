package com.comp301.a09nonograms.view;

import com.comp301.a09nonograms.controller.Controller;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class LeftLabels implements FXComponent {
  private final Controller controller;

  public LeftLabels(Controller controller) {
    this.controller = controller;
  }

  @Override
  public Parent render() {
    VBox leftlabels = new VBox();
    // ArrayList<HBox> sideclues = new ArrayList<>();
    int[] a1;
    for (int v = 0; v < this.controller.getClues().getHeight(); v++) {
      a1 = this.controller.getClues().getRowClues(v);
      HBox temp = new HBox();
      // make vboxes with number of clues
      for (int x = 0; x < this.controller.getClues().getRowCluesLength(); x++) {
        Button l = new Button(String.valueOf(this.controller.getClues().getRowClues(v)[x]));

        if (this.controller.getClues().getRowClues(v)[x] == 0) {
          l = new Button("");
        }
        l.setPrefSize(60, 60);

        temp.getChildren().add(l);
      }
      leftlabels.getChildren().add(temp);
    }

    // for (int a = 0; a < this.controller.getClues().getHeight(); a++) {
    //  leftlabels.getChildren().add(sideclues.get(a));
    // }

    return leftlabels;
  }
}
