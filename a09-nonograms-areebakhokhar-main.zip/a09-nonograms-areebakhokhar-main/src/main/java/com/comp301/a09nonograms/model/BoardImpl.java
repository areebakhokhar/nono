package com.comp301.a09nonograms.model;

import java.util.Arrays;

public class BoardImpl implements Board {
  private final int[][] board;
  private final int rows;
  private final int cols;

  public BoardImpl(int height, int width) {
    if (height < 0 || width < 0) {
      throw new IllegalArgumentException();
    }
    this.board = new int[height][width];
    this.rows = height;
    this.cols = width;
  }

  @Override
  public boolean isShaded(int row, int col) {
    // 1 shaded
    // 0 space
    // -1 eliminated
    if (row < 0 || col < 0 || row >= this.rows || col >= this.cols) {
      throw new IllegalArgumentException();
    }
    return this.board[row][col] == 1;
  }

  @Override
  public boolean isEliminated(int row, int col) {
    // 1 shaded
    // 0 space
    // -1 eliminated
    if (row < 0 || col < 0 || row >= this.rows || col >= this.cols) {
      throw new IllegalArgumentException();
    }
    return this.board[row][col] == -1;
  }

  @Override
  public boolean isSpace(int row, int col) {
    // 1 shaded
    // 0 space
    // -1 eliminated
    if (row < 0 || col < 0 || row >= this.rows || col >= this.cols) {
      throw new IllegalArgumentException();
    }
    return this.board[row][col] == 0;
  }

  @Override
  public void toggleCellShaded(int row, int col) {
    // 1 shaded
    // 0 space
    // -1 eliminated
    if (row < 0 || col < 0 || row >= this.rows || col >= this.cols) {
      throw new IllegalArgumentException();
    }
    if (this.board[row][col] == 1) {
      this.board[row][col] = 0;
    } else if (this.board[row][col] == -1) {
      this.board[row][col] = 0;
    } else {
      this.board[row][col] = 1;
    }
  }

  @Override
  public void toggleCellEliminated(int row, int col) {
    // 1 shaded
    // 0 space
    // -1 eliminated
    if (row < 0 || col < 0 || row >= this.rows || col >= this.cols) {
      throw new IllegalArgumentException();
    }
    if (this.board[row][col] == -1) {
      this.board[row][col] = 0;
    } else if (this.board[row][col] == 1) {
      this.board[row][col] = 0;
    } else {
      this.board[row][col] = -1;
    }
  }

  @Override
  public void clear() {
    for (int[] row : this.board) Arrays.fill(row, 0);
  }
}
